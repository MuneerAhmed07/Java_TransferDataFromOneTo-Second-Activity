package com.example.task_three;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends AppCompatActivity {

//   we create Variable
    EditText firstName;
    EditText lastName;
    RadioButton Male;
    RadioButton Female;
    EditText Email;
    EditText Address;
    EditText currentAddress;
    Button SignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        Select all input field using it's id

        firstName = findViewById(R.id.fname);
        lastName = findViewById(R.id.lname);
        Male = findViewById(R.id.male);
        Female = findViewById(R.id.female);
        Email = findViewById(R.id.email);
        Address = findViewById(R.id.address);
        currentAddress = findViewById(R.id.c_address);
        SignUp = findViewById(R.id.button);

//        set a click event on a Button

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String GetFirstName = firstName.getText().toString();
                String GetLastName = lastName.getText().toString();
                String GetMaleValue = Male.getText().toString();
                String GetFemaleValue = Female.getText().toString();
                String GetEmail = Email.getText().toString();
                String GetAddress = Address.getText().toString();
                String GetCurrentAddress = currentAddress.getText().toString();

//                Intent Method (set target activity)

                Intent intent = new Intent(MainActivity.this, MainActivity2.class);

                intent.putExtra("FirstName", GetFirstName);
                intent.putExtra("LastName", GetLastName);
                intent.putExtra("Male", GetMaleValue);
                intent.putExtra("Female", GetFemaleValue);
                intent.putExtra("Email", GetEmail);
                intent.putExtra("Address", GetAddress);
                intent.putExtra("CurrentAddress", GetCurrentAddress);
                startActivity(intent);
            }
        });

    }
}