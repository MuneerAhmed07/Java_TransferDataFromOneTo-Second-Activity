package com.example.task_three;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intent = getIntent();
        String firstname = intent.getStringExtra("FirstName");
        String lastname = intent.getStringExtra("LastName");
        String Male = intent.getStringExtra("Male");
        String Female = intent.getStringExtra("Female");
        String Email = intent.getStringExtra("Email");
        String Address = intent.getStringExtra("Address");
        String CurrentAddress = intent.getStringExtra("CurrentAddress");

        // select textView by its id

        TextView Result = findViewById(R.id.result);

//        Set text in A textView

        Result.setText("FirstName : " + firstname + "\nLastName : " + lastname + "\nMale : " + Male + "\nFemale : " + Female
        + "\nEmail : " + Email + "\nAddress : " + Address + "\nCurrentAddress : " + CurrentAddress);

    }
}